#define VERSION 3.82
#define VERSION_STR "3.82"
#define VERSION_MAJOR 3
#define VERSION_MINOR 82
#define YEAR 2009
#define YEAR_STR "2009"
